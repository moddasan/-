import { create } from 'zustand';

type Point = { x: number; y: number };

type Obstacle = {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
};

type State = {
  start: Point;
  goal: Point;
  obstacles: Obstacle[];
  jointAngles: number[]; // [base, shoulder, elbow] в градусах
  trajectory: Point[];   // Розрахована траєкторія кінцевого ефектора

  setStart: (p: Point) => void;
  setGoal: (p: Point) => void;
  addObstacle: (obs: Obstacle) => void;
  removeObstacle: (id: string) => void;
  setJointAngles: (angles: number[]) => void;
  setTrajectory: (traj: Point[]) => void;
};

export const useStore = create<State>((set) => ({
  start: { x: 100, y: 300 },
  goal: { x: 400, y: 300 },
  obstacles: [
    { id: '1', x: 200, y: 200, width: 80, height: 200 },
  ],
  jointAngles: [0, 45, -30],
  trajectory: [],

  setStart: (p) => set({ start: p }),
  setGoal: (p) => set({ goal: p }),
  addObstacle: (obs) => set((state) => ({ obstacles: [...state.obstacles, obs] })),
  removeObstacle: (id) => set((state) => ({ obstacles: state.obstacles.filter(o => o.id !== id) })),
  setJointAngles: (angles) => set({ jointAngles: angles }),
  setTrajectory: (traj) => set({ trajectory: traj }),
}));