"use client";

import { Stage, Layer, Rect, Circle, Line, Text } from "react-konva";
import { useStore } from "@/store/useStore";
import { computeLinkPoints } from '@/lib/kinematics';

export function Canvas2D() {
  const { start, goal, obstacles, jointAngles, trajectory } = useStore();

  const jointPoints = computeLinkPoints(jointAngles);
  const points: number[] = jointPoints.flatMap(p => [p.x, p.y]);

  return (
    <Stage width={700} height={600} className="bg-white shadow-lg">
      <Layer>
        {/* Сітка */}
        <Rect x={0} y={0} width={700} height={600} fill="#f9fafb" />
        {Array.from({ length: 35 }).map((_, i) => (
          <Line
            key={i}
            points={[i * 20, 0, i * 20, 600]}
            stroke="#e5e7eb"
            strokeWidth={1}
          />
        ))}
        {Array.from({ length: 30 }).map((_, i) => (
          <Line
            key={i + 100}
            points={[0, i * 20, 700, i * 20]}
            stroke="#e5e7eb"
            strokeWidth={1}
          />
        ))}

        {/* Перешкоди */}
        {obstacles.map((obs) => (
          <Rect
            key={obs.id}
            x={obs.x}
            y={obs.y}
            width={obs.width}
            height={obs.height}
            fill="#ef4444"
            opacity={0.6}
          />
        ))}

        {/* Старт і мета */}
        <Circle x={start.x} y={start.y} radius={12} fill="#10b981" />
        <Text text="Старт" x={start.x - 20} y={start.y + 20} fontSize={14} />
        <Circle x={goal.x} y={goal.y} radius={12} fill="#3b82f6" />
        <Text text="Мета" x={goal.x - 15} y={goal.y + 20} fontSize={14} />

        {/* Робот */}
        <Line points={points} stroke="#1f2937" strokeWidth={8} />
        {jointPoints.map((p, i) => (
          <Circle key={i} x={p.x} y={p.y} radius={8} fill="#1e40af" />
        ))}

        {/* Траєкторія (якщо є) */}
        {trajectory.length > 0 && (
          <Line
            points={trajectory.flatMap(p => [p.x, p.y])}
            stroke="#fbbf24"
            strokeWidth={4}
            dash={[10, 5]}
          />
        )}
      </Layer>
    </Stage>
  );
}
