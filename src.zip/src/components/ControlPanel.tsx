"use client";

import { useStore } from "@/store/useStore";
import { Trash2 } from "lucide-react";

export function ControlPanel() {
  const { jointAngles, setJointAngles, obstacles, removeObstacle, setTrajectory } = useStore();

  const handleAngleChange = (index: number, value: string) => {
    const newAngles = [...jointAngles];
    newAngles[index] = Number(value);
    setJointAngles(newAngles);
  };

  // Простий приклад розрахунку траєкторії (лінійна інтерполяція)
  const calculateTrajectory = () => {
    const steps = 50;
    const traj = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      traj.push({
        x: 100 + t * 300,
        y: 300 + Math.sin(t * Math.PI) * 100,
      });
    }
    setTrajectory(traj);
  };

  return (
    <div className="w-80 bg-gray-100 p-6 overflow-y-auto">
      <h2 className="text-xl font-bold mb-6">Параметри</h2>

      <div className="space-y-4 mb-8">
        <h3 className="font-semibold">Кути суглобів (°)</h3>
        {["База", "Плече", "Лікоть"].map((label, i) => (
          <div key={i}>
            <label className="block text-sm">{label}</label>
            <input
              type="range"
              min="-180"
              max="180"
              value={jointAngles[i]}
              onChange={(e) => handleAngleChange(i, e.target.value)}
              className="w-full"
            />
            <span className="text-sm">{jointAngles[i]}°</span>
          </div>
        ))}
      </div>

      <button
        onClick={calculateTrajectory}
        className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mb-6"
      >
        Розрахувати траєкторію
      </button>

      <div>
        <h3 className="font-semibold mb-2">Перешкоди ({obstacles.length})</h3>
        {obstacles.map((obs) => (
          <div key={obs.id} className="flex justify-between items-center bg-white p-2 rounded mb-2">
            <span className="text-sm">x:{obs.x} y:{obs.y}</span>
            <button onClick={() => removeObstacle(obs.id)}>
              <Trash2 size={16} className="text-red-600" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}