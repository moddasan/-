"use client";

import { Home, Settings, FolderOpen, Download, Info } from "lucide-react";

export function Sidebar() {
  const menuItems = [
    { icon: Home, label: "Головна", active: true },
    { icon: Settings, label: "Параметри маніпулятора" },
    { icon: FolderOpen, label: "Керування проєктом" },
    { icon: Download, label: "Експорт траєкторії" },
    { icon: Info, label: "Довідка" },
  ];

  return (
    <aside className="w-64 bg-gray-800 text-white p-6">
      <h1 className="text-2xl font-bold mb-10">
        Робот-маніпулятор 2D
      </h1>
      <p className="text-sm opacity-80 mb-2">Чеповський Д. Ю.</p>
      <p className="text-xs opacity-60 mb-8">Група ТВ-22</p>

      <nav className="space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.label}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition
              ${item.active ? "bg-blue-600" : "hover:bg-gray-700"}`}
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}