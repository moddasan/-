import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Sidebar } from "@/components/Sidebar/Sidebar";

const inter = Inter({ subsets: ["latin", "cyrillic"] });

export const metadata: Metadata = {
  title: "Оптимізація траєкторії робота-маніпулятора (2D)",
  description: "Дипломний проєкт Чеповського Д. Ю.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uk">
      <body className={`${inter.className} bg-gray-50`}>
        <div className="flex h-screen">
          <Sidebar />
          <main className="flex-1 flex overflow-hidden">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}