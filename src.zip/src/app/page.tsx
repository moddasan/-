"use client";

import { Canvas2D } from "@/components/Canvas2D";
import { ControlPanel } from "@/components/ControlPanel";

export default function Home() {
  return (
    <>
      <Canvas2D />
      <ControlPanel />
    </>
  );
}