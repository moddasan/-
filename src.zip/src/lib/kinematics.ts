export type Point = { x: number; y: number };

// Centralized link lengths and base position used by both store and canvas
export const LINK_LENGTHS = [150, 120, 80];
export const BASE_POSITION: Point = { x: 250, y: 300 };

// Compute absolute joint points (including base) for Konva canvas coordinates
// Angles are expected in degrees. Uses the same convention as Canvas2D rendering
export function computeLinkPoints(angles: number[]): Point[] {
  const points: Point[] = [{ x: BASE_POSITION.x, y: BASE_POSITION.y }];
  let currentAngle = 0;
  for (let i = 0; i < angles.length; i++) {
    currentAngle += (angles[i] * Math.PI) / 180;
    const last = points[points.length - 1];
    const l = LINK_LENGTHS[i] ?? LINK_LENGTHS[LINK_LENGTHS.length - 1];
    const nx = last.x + l * Math.cos(currentAngle);
    const ny = last.y - l * Math.sin(currentAngle); // Konva Y goes down, so subtract
    points.push({ x: nx, y: ny });
  }
  return points;
}

export function computeEndEffector(angles: number[]) {
  const pts = computeLinkPoints(angles);
  return pts[pts.length - 1];
}
