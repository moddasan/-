package com.example.main

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PMCalculatorApp()
            }
        }
    }
}

@Composable
fun PMCalculatorApp() {
    var coalTonnesStr by remember { mutableStateOf("1096363") }
    var oilTonnesStr by remember { mutableStateOf("70945") }
    var gasM3Str by remember { mutableStateOf("84762000") }

    var coalAshPercentStr by remember { mutableStateOf("25.20") }
    var coalFlyFractionStr by remember { mutableStateOf("0.70") }

    var oilMoisturePercentStr by remember { mutableStateOf("2.0") }
    var oilAshDryPercentStr by remember { mutableStateOf("0.15") }

    var gasDensityStr by remember { mutableStateOf("0.723") }
    var espEfficiencyStr by remember { mutableStateOf("0.985") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Калькулятор валових викидів зважених твердих частинок (PM)",
                fontSize = 20.sp
            )
            Spacer(Modifier.height(12.dp))

            SectionTitle("Вхідні дані (кількості палива)")
            NumberInput("Вугілля (тонн)", coalTonnesStr) { coalTonnesStr = it }
            NumberInput("Мазут (тонн)", oilTonnesStr) { oilTonnesStr = it }
            NumberInput("Природний газ (м³)", gasM3Str) { gasM3Str = it }

            Spacer(Modifier.height(8.dp))
            SectionTitle("Параметри палива")
            NumberInput("Зольність вугілля Ar (%)", coalAshPercentStr) { coalAshPercentStr = it }
            NumberInput("Доля леткої/пилової золи (0..1)", coalFlyFractionStr) { coalFlyFractionStr = it }
            NumberInput("Мокрість мазуту W (%)", oilMoisturePercentStr) { oilMoisturePercentStr = it }
            NumberInput("Зольність сухої маси мазуту (%)", oilAshDryPercentStr) { oilAshDryPercentStr = it }
            NumberInput("Густина газу (кг/м³)", gasDensityStr) { gasDensityStr = it }

            Spacer(Modifier.height(8.dp))
            SectionTitle("Установка уловлювання / інші")
            NumberInput("Ефективність ЕГА (0..1)", espEfficiencyStr) { espEfficiencyStr = it }

            Spacer(Modifier.height(12.dp))

            val results = remember(
                coalTonnesStr,
                oilTonnesStr,
                gasM3Str,
                coalAshPercentStr,
                coalFlyFractionStr,
                oilMoisturePercentStr,
                oilAshDryPercentStr,
                gasDensityStr,
                espEfficiencyStr
            ) {
                try {
                    computeAll(
                        coalTonnes = coalTonnesStr.toDouble(),
                        oilTonnes = oilTonnesStr.toDouble(),
                        gasM3 = gasM3Str.toDouble(),
                        coalAshPercent = coalAshPercentStr.toDouble(),
                        coalFlyFraction = coalFlyFractionStr.toDouble(),
                        oilMoisturePercent = oilMoisturePercentStr.toDouble(),
                        oilAshDryPercent = oilAshDryPercentStr.toDouble(),
                        gasDensity = gasDensityStr.toDouble(),
                        espEfficiency = espEfficiencyStr.toDouble()
                    )
                } catch (e: Exception) {
                    CalculationResult.error("Невірні вхідні дані")
                }
            }

            ResultsBlock(results)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NumberInput(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}

@Composable
fun ResultsBlock(res: CalculationResult) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("Результати", fontSize = 18.sp)
            Spacer(modifier = Modifier.height(8.dp))
            if (res.error != null) {
                Text("Помилка: ${res.error}")
                return@Column
            }
            Text("Золa від вугілля (кг): ${formatKg(res.coalAshKg)}")
            Text("Леткова (fly) зола, кг: ${formatKg(res.coalFlyAshKg)}")
            Text("Викид PM після ЕГА від вугілля, кг: ${formatKg(res.emittedCoalKg)}")
            Spacer(modifier = Modifier.height(6.dp))
            Text("Золa від мазуту (кг): ${formatKg(res.oilAshKg)}")
            Text("Викид PM після ЕГА від мазуту, кг: ${formatKg(res.emittedOilKg)}")
            Spacer(modifier = Modifier.height(6.dp))
            Text("Маса газу, кг: ${formatKg(res.gasMassKg)}")
            Text("Викид PM від газу, кг: ${formatKg(res.emittedGasKg)}")
            Spacer(modifier = Modifier.height(8.dp))
            Text("Всього викидів PM (кг): ${formatKg(res.totalEmittedKg)}", fontSize = 16.sp)
            Text(
                "Всього викидів PM (тонн): ${
                    String.format(
                        Locale("ru"),
                        "%.3f",
                        res.totalEmittedKg / 1000.0
                    )
                }"
            )
        }
    }
}

fun formatKg(v: Double): String = String.format(Locale("ru"), "%,.2f", v)

data class CalculationResult(
    val coalAshKg: Double = 0.0,
    val coalFlyAshKg: Double = 0.0,
    val emittedCoalKg: Double = 0.0,
    val oilAshKg: Double = 0.0,
    val emittedOilKg: Double = 0.0,
    val gasMassKg: Double = 0.0,
    val emittedGasKg: Double = 0.0,
    val totalEmittedKg: Double = 0.0,
    val error: String? = null
) {
    companion object {
        fun error(msg: String) = CalculationResult(error = msg)
    }
}

fun computeAll(
    coalTonnes: Double,
    oilTonnes: Double,
    gasM3: Double,
    coalAshPercent: Double,
    coalFlyFraction: Double,
    oilMoisturePercent: Double,
    oilAshDryPercent: Double,
    gasDensity: Double,
    espEfficiency: Double
): CalculationResult {
    val coalKg = coalTonnes * 1000.0
    val oilKg = oilTonnes * 1000.0
    val gasKg = gasM3 * gasDensity

    val coalAshKg = coalKg * (coalAshPercent / 100.0)
    val coalFlyAshKg = coalAshKg * coalFlyFraction
    val emittedCoalKg = coalFlyAshKg * (1.0 - espEfficiency)

    val oilDryKg = oilKg * (1.0 - (oilMoisturePercent / 100.0))
    val oilAshKg = oilDryKg * (oilAshDryPercent / 100.0)
    val emittedOilKg = oilAshKg * (1.0 - espEfficiency)

    val gasAshKg = 0.0
    val emittedGasKg = gasAshKg * (1.0 - espEfficiency)

    val total = emittedCoalKg + emittedOilKg + emittedGasKg

    return CalculationResult(
        coalAshKg = coalAshKg,
        coalFlyAshKg = coalFlyAshKg,
        emittedCoalKg = emittedCoalKg,
        oilAshKg = oilAshKg,
        emittedOilKg = emittedOilKg,
        gasMassKg = gasKg,
        emittedGasKg = emittedGasKg,
        totalEmittedKg = total
    )
}
